<?php include_once 'includes/db_connection.php'; ?>
<?php include_once 'includes/header.php'; ?>

        <!-- Home -->
        <div id="home" class="hero-area">

            <!-- Backgound Image -->
            <div class="bg-image bg-parallax overlay" style="background-image:url(./img/home-background.jpg)"></div>
            <!-- /Backgound Image -->

            <div class="home-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <h1 class="white-text">UPSKILLS ACADEMY FOR COURSE TRAINING</h1>
                            <p class="lead white-text">Libris vivendo eloquentiam ex ius, nec id splendide abhorreant, eu pro alii error homero.</p>
                            <!--<a class="main-button icon-button" href="#">Get Started!</a>-->
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- /Home -->

        <!-- About -->
        <div id="about" class="section">

            <!-- container -->
            <div class="container">

                <!-- row -->
                <div class="row" id="about">

                    <div class="col-md-6">
                        <div class="section-header">
                            <h2 style="color: orange">Welcome to UPSKILLS</h2>

                        </div>

                        <!-- feature -->
                        <div class="feature">
                            <i class="feature-icon fa fa-flask"></i>
                            <div class="feature-content">
                                <h4>Practical experienc </h4>
                                <p>Ceteros fuisset mei no, soleat epicurei adipiscing ne vis. Et his suas veniam nominati.</p>
                            </div>
                        </div>
                        <!-- /feature -->

                        <!-- feature -->
                        <div class="feature">
                            <i class="feature-icon fa fa-users"></i>
                            <div class="feature-content">
                                <h4>Expert Teachers</h4>
                                <p>Ceteros fuisset mei no, soleat epicurei adipiscing ne vis. Et his suas veniam nominati.</p>
                            </div>
                        </div>
                        <!-- /feature -->

                        <!-- feature -->
                        <div class="feature">
                            <i class="feature-icon fa fa-comments"></i>
                            <div class="feature-content">
                                <h4>Community</h4>
                                <p>Ceteros fuisset mei no, soleat epicurei adipiscing ne vis. Et his suas veniam nominati.</p>
                            </div>
                        </div>
                        <!-- /feature -->

                    </div>

                    <div class="col-md-6">
                        <div class="about-img">
                            <img src="./img/about.png" alt="">
                        </div>
                    </div>

                </div>
                <!-- row -->

            </div>
            <!-- container -->
        </div>
        <!-- /About -->

        <!-- Courses -->
        <div id="courses" class="section">

            <!-- container -->
            <div class="container">

                <!-- row -->
                <div class="row">
                    <div class="section-header text-center">
                        <h2>Explore Courses</h2>
                        <p class="lead">show our latest courses.</p>
                    </div>
                </div>
                <!-- /row -->

                <!-- courses -->
                <div id="courses-wrapper">
                <!-- single course -->
                    <!-- row -->
                    <div class="row">
                    <?php
                    // fetch all cat 
                    $query= "select * from category";
                    $result= mysqli_query($link, $query);                            
                    while($row= mysqli_fetch_assoc($result)){
                        echo '<div class="col-md-3 col-sm-6 col-xs-6">';
                        echo '<div class="course">';
                        echo "<a href='course.php?cat_id={$row['cat_id']}' class='course-img'>";
                        echo "<img src='uploads/{$row['cat_image']}' style='width: 300px;height: 180px;'>";
                        echo '<i class="cou0rse-link-icon fa fa-link"></i></a>';
                        echo "<a class='course-title' href='#'>{$row['cat_name']}</a>";
                        echo '<div class="course-details"></div></div></div>';                        
                    }                    
                    ?>
                 </div>
                    <!-- /row -->

                </div>
                <!-- /courses -->

                <div class="row">
                    <div class="center-btn">
                        <a class="main-button icon-button" href="#">More Courses</a>
                    </div>
                </div>

            </div>
            <!-- container -->

        </div>
        <!-- /Courses -->

        <!-- Call To Action -->
        <div id="cta" class="section">

            <!-- Backgound Image -->
            <div class="bg-image bg-parallax overlay" style="background-image:url(./img/salameh.jpg)"></div>
            <!-- /Backgound Image -->

            <!-- container -->
            <div class="container">

                <!-- row -->
                <div class="row">

                    <div class="col-md-6">
                        <h2 class="white-text">photo gallery</h2>
                        <p class="lead white-text">LET PHOTO TALK.....</p>
                        <a class="main-button icon-button" href="photo.php">Get Started!</a>

                    </div>

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /Call To Action -->

        <!-- Why us -->
        <div id="why-us" class="section">

            <!-- container -->
            <div class="container">

                <!-- row -->
                <div class="row">
                    <div class="section-header text-center">
                        <h2>Why UP SKILLS</h2>
                        <p class="lead"> </p>
                    </div>

                    <!-- feature -->
                    <div class="col-md-4" id="ab">
                        <div class="feature">
                            <i class="feature-icon fa fa-flask"></i>
                            <div class="feature-content">
                                <h4>Practical experience</h4>
                                <p>Ceteros fuisset mei no, soleat epicurei adipiscing ne vis. Et his suas veniam nominati.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /feature -->

                    <!-- feature -->
                    <div class="col-md-4">
                        <div class="feature">
                            <i class="feature-icon fa fa-users"></i>
                            <div class="feature-content">
                                <h4>Expert Teachers</h4>
                                <p>Ceteros fuisset mei no, soleat epicurei adipiscing ne vis. Et his suas veniam nominati.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /feature -->

                    <!-- feature -->
                    <div class="col-md-4">
                        <div class="feature">
                            <i class="feature-icon fa fa-comments"></i>
                            <div class="feature-content">
                                <h4>Events</h4>
                                <p>Ceteros fuisset mei no, soleat epicurei adipiscing ne vis. Et his suas veniam nominati.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /feature -->

                </div>
                <!-- /row -->

                <hr class="section-hr">

                <!-- row -->
                <div class="row">

                    <div class="col-md-6">
                        <h3>Persius imperdiet incorrupte et qui, munere nusquam et nec.</h3>
                        <p class="lead">Libris vivendo eloquentiam ex ius, nec id splendide abhorreant.</p>
                        <p>No vel facete sententiae, quodsi dolores no quo, pri ex tamquam interesset necessitatibus. Te denique cotidieque delicatissimi sed. Eu doming epicurei duo. Sit ea perfecto deseruisse theophrastus. At sed malis hendrerit, elitr deseruisse in sit, sit ei facilisi mediocrem.</p>
                    </div>

                    <div class="col-md-5 col-md-offset-1">
                        <a class="about-video" href="#">
                            <img src="./img/about-video.jpg" alt="">
                            <i class="play-icon fa fa-play"> </i>
                        </a>
                    </div>

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /Why us -->

        <!-- Contact CTA -->
        <div id="contact-cta" class="section">

            <!-- Backgound Image -->
            <div class="bg-image bg-parallax overlay" style="background-image:url(./img/cta2-background.jpg)"></div>
            <!-- Backgound Image -->

            <!-- container -->
            <div class="container">

                <!-- row -->
                <div class="row">

                    <div class="col-md-8 col-md-offset-2 text-center">
                        <h2 class="white-text">Contact Us</h2>
                        <p class="lead white-text">To know about us </p>
                        <a class="main-button icon-button" href="contact.html">Contact Us Now</a>
                    </div>

                </div>
                <!-- /row -->

            </div>
            <!-- /container -->

        </div>
        <!-- /Contact CTA -->

        <!-- Footer -->
        <footer id="footer" class="section">

            <!-- container -->
            <div class="container">

                <!-- row -->
                <div class="row">

                    <!-- footer logo -->
                    <div class="col-md-6">
                        <div class="footer-logo">
                            <a class="logo" href="index.html">
                                <!--<img src="./img/logo.png" alt="logo">-->
                                <h1 style="color: orange">UP SKILLS</h1>
                            </a>
                        </div>
                    </div>
                    <!-- footer logo -->

                    <!-- footer nav -->
                    <div class="col-md-6">
                        <ul class="footer-nav">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="#">About</a></li>
                            <li><a href="#">Courses</a></li>
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                    <!-- /footer nav -->

                </div>
                <!-- /row -->

                <!-- row -->
                <div id="bottom-footer" class="row">

                    <!-- social -->
                    <div class="col-md-4 col-md-push-8">
                        <ul class="footer-social">
                            <li><a href="https://web.facebook.com/upskills1/" class="facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#" class="instagram"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                    <!-- /social -->

                    <!-- copyright -->
                    <div class="col-md-8 col-md-pull-4">
                        <div class="footer-copyright">
                            <span>&copy; Copyright 2018. All Rights Reserved. | made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://web.facebook.com/upskills1/">UP SKILLS</a></span>
                        </div>
                    </div>
                    <!-- /copyright -->

                </div>
                <!-- row -->

            </div>
            <!-- /container -->

        </footer>
        <!-- /Footer -->

        <!-- preloader -->
        <div id='preloader'><div class='preloader'></div></div>
        <!-- /preloader -->


        <!-- jQuery Plugins -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/main.js"></script>

    </body>
</html>
