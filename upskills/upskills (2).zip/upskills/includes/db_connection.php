<?php
//open connection to DB
    $link = mysqli_connect("localhost","root","","upskills");
    if(!$link){
        die("cannot connect to server");
    }
   